const users = [
  {
    username: "johndoe",
    email: "johndoe@example.com",
    password: "password1",
    role: "admin",
  },
  {
    username: "janedoe",
    email: "janedoe@example.com",
    password: "password2",
    role: "user",
  },
  {
    username: "bobsmith",
    email: "bobsmith@example.com",
    password: "password3",
    role: "admin",
  },
  {
    username: "sarahlee",
    email: "sarahlee@example.com",
    password: "password4",
    role: "guest",
  },
  {
    username: "maxking",
    email: "maxking@example.com",
    password: "password5",
    role: "superadmin",
  },
];

module.exports = users;